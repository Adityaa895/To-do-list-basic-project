import json

class Task_manager:
    def __init__(self):

        self.tasks=[]  # List to store all tasks

        try:
            with open("tasks.json","r") as tempfile:
                self.tasks = json.load(tempfile)
        except:
            self.tasks = []
        
    def task_inputed(self,title,schedule):

            temptasks={}
                    
            temptasks["title"]= title
            temptasks["schedule date"] = schedule
            temptasks["status"] = "Pending"

            if any(task["title"] == title for task in self.tasks ):
                return False
            else:
                self.tasks.append(temptasks)
                return True

    def initial_tasks_file(self):         

         with open("tasks.json","w") as taskfile:
          json.dump(self.tasks,taskfile,indent=4)

    def add_button(self):

        if self.task_inputed():
            self.initial_tasks_file()

    # Delete tasks & update the file
    def delete_bt(self,tempindex):

        if 0 <= tempindex <= len(self.tasks):

            self.tasks.pop(tempindex)
            self.initial_tasks_file()

    def update_status(self,tempindex):

         for task in enumerate(self.tasks):
            self.tasks[tempindex]["status"] = "Completed"

         self.initial_tasks_file()
