from .gui import Gui_funct

def main():
    Gui_funct()

if __name__ == "__main__":
    main()