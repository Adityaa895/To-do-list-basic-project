from .core import Task_manager
import tkinter as tk

class Gui_funct():

    def __init__(self):

        root=tk.Tk()
        root.geometry("800x670")
        root.title("To-Do List")

        self.manager = Task_manager()

        self.title_label = tk.Label(root, text="--- TO DO List ---", font=("gothic",34,"bold"))
        self.title_label.pack(pady=40)

        self.title_label=tk.Label(root, text="Enter your task's title",font=("Arial",15,"italic"))
        self.title_label.pack(pady=10)

        self.title_entry= tk.Entry(root,width=25)
        self.title_entry.pack(pady=5)

        self.schedule_label=tk.Label(root, text="Enter your task's schedule date",font=("Arial",14,"italic"))
        self.schedule_label.pack(pady=10)

        self.schedule_entry= tk.Entry(root,width=25)
        self.schedule_entry.pack(pady=5)

        self.add_bt = tk.Button(root,text=" Add task ",font=("gothic",9),bd=2, width=8, height=2, command = self.task_entry )
        self.add_bt.pack(pady=7)

        self.delete_bt = tk.Button(root,text="Delete task",font=("gothic",9),bd=2, width=11, height=2, command = self.delete_button)
        self.delete_bt.pack(pady=7)

        self.update_bt = tk.Button(root,text="Update status",font=("gothic",9),bd=2, width=13, height=2, command = self.status_button)
        self.update_bt.pack(pady=7)


        self.taskbox = tk.Listbox(root,width=70,height=80)
        self.taskbox.pack(pady=7)
        self.refresh_button()

        root.mainloop()


    def task_entry(self):

        self.title = self.title_entry.get()
        self.schedule = self.schedule_entry.get()

        self.manager.task_inputed(self.title,self.schedule)

        self.manager.initial_tasks_file()
        self.refresh_button()

    def refresh_button(self):

        self.taskbox.delete(0,tk.END)

        for i,task in enumerate(self.manager.tasks):

            self.taskbox.insert(tk.END, f"{i+1}. Title : {task['title']} , Schedule date : {task['schedule date']} , Status : {task['status']}")

    def delete_button(self):

        selected = self.taskbox.curselection()
        tempindex = selected[0]

        self.manager.delete_bt(tempindex)
        self.refresh_button()

    def status_button(self):

        selected = self.taskbox.curselection()
        tempindex = selected[0]

        self.manager.update_status(tempindex)
        self.refresh_button()